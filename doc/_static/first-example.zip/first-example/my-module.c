#include <stdio.h>

void MyModuleDoAction (void)
{
  printf ("You called MyModuleDoAction !\n");
}
