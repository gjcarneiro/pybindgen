void MyModuleDoAction (void);
